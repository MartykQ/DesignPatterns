﻿using System;

namespace DDD.CarRentalLib
{
    public class Class1
    {
    }
}
