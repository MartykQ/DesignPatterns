﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DDD.Base.DomainModelLayer.Services
{
    public interface IDomainService
    {
    }
}
