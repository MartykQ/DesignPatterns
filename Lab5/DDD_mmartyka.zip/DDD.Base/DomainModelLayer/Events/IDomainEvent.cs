﻿namespace DDD.Base.DomainModelLayer.Events
{
    public interface IDomainEvent
    {
    }
}
