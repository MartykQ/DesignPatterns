﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DDD.Base.InfrastructureLayer.Services
{
    public interface IInfrastructureService
    {
    }
}
