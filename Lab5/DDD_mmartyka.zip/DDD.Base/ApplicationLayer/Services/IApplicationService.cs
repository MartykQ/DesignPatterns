﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DDD.Base.ApplicationLayer.Services
{
    public interface IApplicationService
    {
    }
}
