﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarRental.DTO
{
    public class DriverDTO
    {
        public int DriverId { get; set; }
        public string LicenseNumber { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

    }
}
