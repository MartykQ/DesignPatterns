﻿using CarRental.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarRental.Queries
{
    public class GetAllCarsQuery : IQuery
    {
    }
}
